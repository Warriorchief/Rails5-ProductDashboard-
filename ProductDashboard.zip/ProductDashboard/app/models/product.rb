class Product < ApplicationRecord
  belongs_to :category, dependent: :destroy
  validates :name, :description, presence: true, length: { in: 2..20 }
  validates :price, presence: true
  validates :category_id, presence: true
end
