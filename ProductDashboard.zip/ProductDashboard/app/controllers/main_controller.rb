class MainController < ApplicationController

  def index
    session[:everything] = Product.all
    render 'index.html.erb'
  end

  def add_product
    render 'new.html.erb'
  end

  def create
    thing = Product.new(name: params[:name],description: params[:description],price: params[:price],category_id: params[:cat_id])
    if thing.save
      flash[:hi] = "Product added to table."
      redirect_to('/')
    else
      flash[:hi] = "Error: every field must be 2-20 characters!"
      redirect_to :back
    end
  end

  def show
    @thing = Product.find(params[:id])
  end

  def edit
    @clown = Product.find(params[:id])
  end

  def update
    @n = params[:new_name]
    @d = params[:new_description]
    @p = params[:new_price]
    @c = params[:cat_id]
    thing = Product.update(params[:special], :name=>@n, :description=> @d, :price=>@p, :category_id=>@c)
    if thing.save
      flash[:hi] = "Updated the information of product with id #{params[:special]}"
      redirect_to('/')
    else
      flash[:hi] = "Every field and each must be between 2-20 characters. Try again."
      redirect_to :back
    end
  end

  def delete
    Product.find(params[:id]).delete
    flash[:hi] = "Product #{params[:id]} deleted"
    redirect_to('/')
  end

end
