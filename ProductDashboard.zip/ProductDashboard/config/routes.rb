Rails.application.routes.draw do
  get '/', :controller=>'main', :action=>'index'

  get '/new_product', :controller=>'main',:action=>'add_product'

  post 'create', :controller=>'main', :action=> 'create'

  get 'products/:id', :controller=>'main', :action=> 'show'

  get 'products/:id/edit', :controller=>'main', :action=> 'edit'

  post 'update', :controller=>'main', :action=>'update'

  delete '/destroy/:id', :controller=>'main', :action=> 'delete'

end
